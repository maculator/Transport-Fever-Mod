function data()
return {
	vehicles = {
		{ name = "vehicle/train/db_v100.mdl", forward = false },

	},
	name = _("Class V 100 R"),
	desc = _("This diesel-hydraulic locomotive was produced for non-electrified branch lines as a replacement for steam locomotives.")
}
end