function data()
return {
	vehicles = {
		{ name = "vehicle/train/br_218.mdl", forward = false },

	},
	name = _("Class 218 R"),
	desc = _("A diesel-hydraulic locomotive from Germany built for medium to heavy trains.")
}
end