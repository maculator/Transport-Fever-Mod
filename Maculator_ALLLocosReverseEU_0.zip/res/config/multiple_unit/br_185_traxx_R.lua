function data()
return {
	vehicles = {
		{ name = "vehicle/train/br_185_traxx.mdl", forward = false },

	},
	name = _("Class 185 R"),
	desc = _("The double voltage Class 185 was meant for international operation, and was also dubbed Europalok.")
}
end