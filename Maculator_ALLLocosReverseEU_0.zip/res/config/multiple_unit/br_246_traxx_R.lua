function data()
return {
	vehicles = {
		{ name = "vehicle/train/br_246_traxx.mdl", forward = false },

	},
	name = _("Class 246 R"),
	desc = _("In this diesel locomotive the fuel tank occupies the same space as the transformer in the electric version.")
}
end