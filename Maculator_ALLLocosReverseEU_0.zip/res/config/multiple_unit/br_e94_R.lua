function data()
return {
	vehicles = {
		{ name = "vehicle/train/br_e94.mdl", forward = false },

	},
	name = _("Class E 94 R"),
	desc = _("This electric heavy freight locomotive was built for the Deutsche Reichsbahn since 1940 and is commonly known as the German Crocodile.")
}
end