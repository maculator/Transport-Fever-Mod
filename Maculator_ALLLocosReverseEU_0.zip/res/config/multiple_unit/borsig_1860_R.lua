function data()
return {
	vehicles = {
		{ name = "vehicle/train/borsig_1860.mdl", forward = false },

	},
	name = _("Borsig R"),
	desc = _("Borsig was a German company based in Berlin. For that time it was a very competitive model, but it was still manufactured without a roofed cabine.")
}
end