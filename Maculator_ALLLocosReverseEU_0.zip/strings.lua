function data()
	return {
--Deutsch
		de = {
		--EU Lokomotiven
			["A 3/5 R"] = "A 3/5 Gedreht",
			["Ae 4/7 R"] = "Ae 4/7 Gedreht",
			["Borsig R"] = "Borsig Gedreht",
			["Class 103 R"] = "BR 103.1 Gedreht",
			["Class 185 R"] = "BR 185 Gedreht",
			["Class 218 R"] = "BR 218 Gedreht",
			["Class 246 R"] = "Baureihe 246 Gedreht",
			["Class E 94 R"] = "BR E 94 Gedreht",
			["Class 53 Prussian G 3 R"] = "BR 53 preuss. G 3 Gedreht",
			["Class 75.4 Baden VI c R"] = "BR 75.4 bad. VI c Gedreht",
			["Class 89 Prussian T 3 R"] = "BR 89 preuss. T 3 Gedreht",
			["Ce 6/8 II Crocodile R"] = "Ce 6/8 II Krokodil Gedreht",
			["D 1/3 R"] = "D 1/3 Gedreht",
			["Class V 100 R"] = "BR V 100 Gedreht",
			["Class A4 R"] = "Klasse A4 Gedreht",
			["Class A3 Flying Scotsman R"] = "Klasse A3 Flying Scotsman Gedreht",
			["NoHAB AA16 R"] = "NoHAB AA16 Gedreht",
			["Class 1042 R"] = "Reihe 1042 Gedreht",
			["PLM 220 R"] = "PLM 220 Gedreht",
			["Re 4/4 R"] = "Re 4/4 Gedreht",
		--Menü
			["ALL Locos Reversed"] = "Alle Lokomotiven gedreht",
			["description"] = "Fügt dem spiel gedrehte Versionen aller Lokomotiven hinzu. Korrekte Namen in Deutsch!",
		},
--English
		en = {
		--EU-Locomotives
			["A 3/5 R"] = "A 3/5 Reversed",
			["Ae 4/7 R"] = "Ae 4/7 Reversed",
			["Borsig R"] = "Borsig Reversed",
			["Class 103 R"] = "Class 103 Reversed",
			["Class 185 R"] = "Class 185 Reversed",
			["Class 218 R"] = "Class 218 Reversed",
			["Class 246"] = "Class 246 Reversed",
			["Class E 94 R"] = "Class E 94 Reversed",
			["Class 53 Prussian G 3 R"] = "Class 53 Prussian G 3 Reversed",
			["Class 75.4 Baden VI c R"] = "Class 75.4 Baden VI c Reversed",
			["Class 89 Prussian T 3 R"] = "Class 89 Prussian T 3 Reversed",
			["Ce 6/8 II Crocodile R"] = "Ce 6/8 II Crocodile Reversed",
			["D 1/3 R"] = "D 1/3 Reversed",
			["Class V 100 R"] = "Class V 100 Reversed",
			["Class A4 R"] = "Class A4 Reversed",
			["Class A3 Flying Scotsman R"] = "Class A3 Flying Scotsman Reversed",
			["NoHAB AA16 R"] = "NoHAB AA16 Reversed",
			["Class 1042 R"] = "Class 1042 Reversed",
			["PLM 220 R"] = "PLM 220 Reversed",
			["Re 4/4 R"] = "Re 4/4 Reversed",
		--Menu
			["ALL Locos Reversed"] ="All Locos reversed",
			["description"] = "Adds reversed versions of all Locomotives.",
		},
	}
end