function data()
	return {  
		info = {
			minorVersion = 0,
			severityAdd = "NONE",
			severityRemove = "NONE",
			name = _("Buslane by Maculator"),
			description = _("replace the buslane texture."),
			authors = {
				{
					name = "Maculator",
					role = "CREATOR",
				},
			},
			tags = {
				"street",
				"texture",
				"buslane",
			},
			visible = true
		},
		runFn = function (settings)
		end
	}
end
