function data()
return {
	vehicles = {
		{ name = "vehicle/train/d1_3_new.mdl", forward = false },

	},
	name = _("D 1/3 R"),
	desc = _("This legendary railway was known as the Spanisch-Brötli-Bahn, named after a delicacy of Baden, Switzerland.")
}
end