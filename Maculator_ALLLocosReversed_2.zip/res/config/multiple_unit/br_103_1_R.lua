function data()
return {
	vehicles = {
		{ name = "vehicle/train/br_103_1.mdl", forward = false },

	},
	name = _("Class 103 R"),
	desc = _("This fast and heavy electric locomotive was, for a long period, the flagship of German rolling stock.")
}
end