function data()
return {
	vehicles = {
		{ name = "vehicle/train/plm_220.mdl", forward = false },

	},
	name = _("PLM 220 R"),
	desc = _("The very futuristic \"Big C\" is a pioneer among the aerodynamic locomotives.")
}
end