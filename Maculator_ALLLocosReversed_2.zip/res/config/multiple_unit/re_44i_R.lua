function data()
return {
	vehicles = {
		{ name = "vehicle/train/re_44i.mdl", forward = false },

	},
	name = _("Re 4/4 R"),
	desc = _("A light-weight locomotive for fast passenger trains, the first in Switzerland equipped with bogies.")
}
end