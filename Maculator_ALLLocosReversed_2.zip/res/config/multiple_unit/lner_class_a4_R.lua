function data()
return {
	vehicles = {
		{ name = "vehicle/train/lner_class_a4.mdl", forward = false },

	},
	name = _("Class A4 R"),
	desc = _("A streamlined 4-6-2 steam locomotive designed by Nigel Gresley for the London and North Eastern Railway. The \"4468 Mallard\" still holds the world record as the fastest steam locomotive.")
}
end