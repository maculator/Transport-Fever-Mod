function data()
return {
	vehicles = {
		{ name = "vehicle/train/a3_5_705.mdl", forward = false },

	},
	name = _("A 3/5 R"),
	desc = _("This 4-6-0 locomotive was the first really fast locomotive of the Jura-Simplon and the Gotthard line.")
}
end