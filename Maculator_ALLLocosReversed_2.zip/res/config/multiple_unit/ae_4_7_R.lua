function data()
return {
	vehicles = {
		{ name = "vehicle/train/ae_4_7.mdl", forward = false },

	},
	name = _("Ae 4/7 R"),
	desc = _("A universal locomotive from Switzerland, very long-lasting thanks to the so-called Buchli drive.")
}
end