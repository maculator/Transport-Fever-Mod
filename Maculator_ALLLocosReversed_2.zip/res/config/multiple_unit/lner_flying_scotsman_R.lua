function data()
return {
	vehicles = {
		{ name = "vehicle/train/lner_flying_scotsman.mdl", forward = false },

	},
	name = _("Class A3 Flying Scotsman R"),
	desc = _("The Flying Scotsman is an express passenger train that has operated between Edinburgh and London, the capitals of Scotland and England via the East Coast Main Line.")
}
end