function data()
return {
	vehicles = {
		{ name = "vehicle/train/br75_4.mdl", forward = false },

	},
	name = _("Class 75.4 Baden VI c R"),
	desc = _("Built by the Maschinenbau-Gesellschaft Karlsruhe for service in south-western Germany, this locomotive was equipped with larger wheels and a longer, fixed wheelbase.")
}
end