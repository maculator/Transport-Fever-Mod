function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/ge_e60c_2.mdl", forward = false },
	},
	name = _("Ge E60C-2 R"),
	desc = _("One type of a modular product platform of electric and diesel-electric mainline locomotives from General Electronics, built in both freight and passenger variants.")
}
end