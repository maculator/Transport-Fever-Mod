function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/mogul_2_6_0.mdl", forward = false },
	},
	name = _("2-6-0 Mogul R"),
	desc = _("The 2-6-0 wheel arrangement was principally used on tender locomotives. This type of locomotive was widely built in the US from the early 1860s to the 1920s.")
}
end