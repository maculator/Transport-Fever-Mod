function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/class_prr_gg1.mdl", forward = false },
	},
	name = _("Class PRR GG1 R"),
	desc = _("Sporting a beautiful streamlined design the GG1 not only looked good but it also performed exemplary reaching speeds and remained in service for many years.")
}
end
