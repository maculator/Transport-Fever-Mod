function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/alco_pb.mdl", forward = false },
		{ name = "vehicle/train/usa/alco_pa.mdl", forward = false },
	},
	name = _("Alco PA/PB R"),
	desc = _("The Alco PB is the cabless booster unit B which matched the PAs and increased the horsepower rating.")
}
end
