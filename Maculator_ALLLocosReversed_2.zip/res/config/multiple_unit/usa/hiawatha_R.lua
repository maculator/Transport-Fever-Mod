function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/hiawatha.mdl", forward = false },
	},
	name = _("4-4-2 Hiawatha R"),
	desc = _("These high-speed, streamlined \"Atlantic\" type locomotives were built by ALCO to haul the Milwaukee Road’s Hiawatha express passenger trains.")
}
end