function data()
return {
	vehicles = {
		{ name = "vehicle/train/c6_8.mdl", forward = false },

	},
	name = _("Ce 6/8 II Crocodile R"),
	desc = _("Swiss electric locomotive known as the Crocodile, mainly used for heavy freight trains on sinuous routes like the Gotthard line.")
}
end