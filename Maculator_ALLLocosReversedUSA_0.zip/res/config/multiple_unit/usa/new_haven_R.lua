function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/new_haven.mdl", forward = false },
	},
	name = _("New Haven EP5 R"),
	desc = _("The New Haven EP-5 was a double-ended mercury arc rectifier electric locomotive built by General Electric. It was built to haul passenger trains between New York City and New Haven.")
}
end