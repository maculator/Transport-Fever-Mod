function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/baldwin_class_56.mdl", forward = false },
	},
	name = _("2-8-0 Baldwin Class 56 R"),
	desc = _("The \"Consolidation\" was a standard freight locomotive and could move trains twice as heavy at half the cost of its predecessors.")
}
end