function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/class_9000.mdl", forward = false },
	},
	name = _("4-12-2 Class 9000 R"),
	desc = _("These locomotives were fairly successful, but maintenance nightmares, because of their inside third cylinder driving the cranked second driving axle between the frames.")
}
end