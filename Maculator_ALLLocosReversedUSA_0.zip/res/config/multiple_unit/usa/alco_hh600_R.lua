function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/alco_hh600.mdl", forward = false },
	},
	name = _("ALCO HH 600 R"),
	desc = _("The ALCO HH series were an early series of switcher diesel-electric locomotives built by the American Locomotive Company (ALCO) of Schenectady, New York.")
}
end