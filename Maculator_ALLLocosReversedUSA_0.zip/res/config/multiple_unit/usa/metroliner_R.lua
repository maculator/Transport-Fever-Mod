function data()
return {
	vehicles = {
		{ name = "vehicle/waggon/usa/amfleet.mdl", forward = false },
		{ name = "vehicle/waggon/usa/amfleet.mdl", forward = false },
		{ name = "vehicle/waggon/usa/amfleet.mdl", forward = false },
		{ name = "vehicle/train/usa/metroliner.mdl", forward = false },

	},
	name = _("Metroliner R"),
	desc = _("The Metroliners, as extra-fare express trains between Washington, D.C., and New York City, were using self-powered electric multiple unit cars.")
}
end
