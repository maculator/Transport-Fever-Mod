function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/emd_gp9_new.mdl", forward = false },
	},
	name = _("EMD GP 9 R"),
	desc = _("GM's Electro-Motive Division GP9 series found enormous success and became one of the most successful diesel locomotives ever built.")
}
end