function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/emd_sd40.mdl", forward = false },
	},
	name = _("EMD SD40-2 R"),
	desc = _("The SD40-2s have become icons. One can spot them in virtually any place on practically any given train.")
}
end