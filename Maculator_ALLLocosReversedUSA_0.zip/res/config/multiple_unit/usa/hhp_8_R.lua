function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/hhp_8.mdl", forward = false },
	},
	name = _("HHP 8 R"),
	desc = _("HHP-8 means High Horse Power 8000. The twin-cab electric locomotive was manufactured for use by Westrail and the Maryland Area Regional Commuter system.")
}
end