function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/ge_c40_8w.mdl", forward = false },
	},
	name = _("GE C40-8W R"),
	desc = _("This 6-axle diesel-electric locomotive built by GE Transportation is distinguished from the Dash 8-40C by the addition of a \"wide\" or \"safety\" cab.")
}
end