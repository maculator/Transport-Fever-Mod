function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/heavy_mikado.mdl", forward = false },
	},
	name = _("2-8-2 Mikado R"),
	desc = _("\"Mikados\" were the most common freight locomotives until the end of steam. More than 9'500 were used in the US.")
}
end