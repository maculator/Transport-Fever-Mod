function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/atlantic_4_4_2.mdl", forward = false },
	},
	name = _("4-4-2 Atlantic R"),
	desc = _("This wheel arrangement is commonly known as the Atlantic type, although it is also sometimes called a Milwaukee.")
}
end