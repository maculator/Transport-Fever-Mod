function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/milw_ep_2.mdl", forward = false },
	},
	name = _("Milwaukee Road class EP-2 R"),
	desc = _("The locomotives, commonly known as Bi-Polars, were one of the most interesting and complex designs ever developed and made up of no less than three articulated sections.")
}
end