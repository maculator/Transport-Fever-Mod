function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/ge_p42_dc.mdl", forward = false },
	},
	name = _("GE P42 DC R"),
	desc = _("The GE Genesis series is unique among recently manufactured North American passenger locomotives in that it uses a single, monocoque carbody design, thus making it lighter.")
}
end