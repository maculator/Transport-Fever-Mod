function data()
	return {  
		info = {
			minorVersion = 0,
			severityAdd = "NONE",
			severityRemove = "NONE",
			name = _("ALL Locos Reversed"),
			description = _("description"),
			authors = {
				{
					name = "Maculator",
					role = "CREATOR",
				},
			},
			tags = {
				"Europe",
				"USA",
				"Locomotive",
			},
			visible = true
		},
		runFn = function (settings)
		end
	}
end
