function data()
	return {
--Deutsch
		de = {
		--US Lokomotiven
			["ALCO HH 600 R"] = "ALCO HH 600 Gedreht",
			["Alco PA/PB R"] = "Alco PA/PB Gedreht",
			["4-4-2 Atlantic R"] = "4-4-2 Atlantic Gedreht",
			["2-8-0 Baldwin Class 56 R"] = "2-8-0 Baldwin-Klasse 56 Gedreht",
			["Baldwin's Six-Wheels R"] = "Baldwin's Six-Wheels Gedreht",
			["4-8-8-4 Big Boy R"] = "4-8-8-4 Big Boy Gedreht",
			["4-12-2 Class 9000 R"] = "4-12-2 Klasse 9000 Gedreht",
			["Class PRR GG1 R"] = "PRR Klasse GG1 Gedreht",
			["EMD AEM-7 R"] = "EMD AEM-7 Gedreht",
			["EMD GP 9 R"] = "EMD GP 9 Gedreht",
			["EMD SD40-2 R"] = "EMD SD40-2 Gedreht",
			["GE C40-8W R"] = "GE C40-8W Gedreht",
			["Ge E60C-2 R"] = "Ge E60C-2 Gedreht",
			["GE P42 DC R"] = "GE P42 DC Gedreht",
			["4-4-0 The General R"] = "4-4-0 The General Gedreht",
			["2-8-2 Mikado R"] = "2-8-2 Mikado Gedreht",
			["HHP 8 R"] = "HHP 8 Gedreht",
			["4-4-2 Hiawatha R"] = "4-4-2 Hiawatha Gedreht",
			["Metroliner R"] = "Metroliner Gedreht",
			["Milwaukee Road class EP-2 R"] = "MILW-Klasse EP-2 Gedreht",
			["2-6-0 Mogul R"] = "2-6-0 Mogul Gedreht",
			["New Haven EP5 R"] = "New Haven EP5 Gedreht",
		--Menü
			["ALL Locos Reversed"] = "Alle Lokomotiven gedreht",
			["description"] = "Fügt dem spiel gedrehte Versionen aller Lokomotiven hinzu. Korrekte Namen in Deutsch!",
		},
--English
		en = {
		--US-Locomotives
			["ALCO HH 600 R"] = "ALCO HH 600 Reversed",
			["Alco PA/PB R"] = "Alco PA/PB Reversed",
			["4-4-2 Atlantic R"] = "4-4-2 Atlantic Reversed",
			["2-8-0 Baldwin Class 56 R"] = "2-8-0 Baldwin Class 56 Reversed",
			["Baldwin's Six-Wheels R"] = "Baldwin's Six-Wheels Reversed",
			["4-8-8-4 Big Boy R"] = "4-8-8-4 Big Boy Reversed",
			["4-12-2 Class 9000 R"] = "4-12-2 Class 9000 Reversed",
			["Class PRR GG1 R"] = "Class PRR GG1 Reversed",
			["EMD AEM-7 R"] = "EMD AEM-7 Reversed",
			["EMD GP 9 R"] = "EMD GP 9 Reversed",
			["EMD SD40-2 R"] = "EMD SD40-2 Reversed",
			["GE C40-8W R"] = "GE C40-8W Reversed",
			["Ge E60C-2 R"] = "Ge E60C-2 Reversed",
			["GE P42 DC R"] = "GE P42 DC Reversed",
			["4-4-0 The General R"] = "4-4-0 The General Reversed",
			["2-8-2 Mikado R"] = "2-8-2 Mikado Reversed",
			["HHP 8 R"] = "HHP 8 Reversed",
			["4-4-2 Hiawatha R"] = "4-4-2 Hiawatha Reversed",
			["Metroliner R"] = "Metroliner Reversed",
			["Milwaukee Road class EP-2 R"] = "Milwaukee Road class EP-2 Reversed",
			["2-6-0 Mogul R"] = "2-6-0 Mogul Reversed",
			["New Haven EP5 R"] = "New Haven EP5 Reversed",
		--Menu
			["ALL Locos Reversed"] ="All Locos reversed",
			["description"] = "Adds reversed versions of all Locomotives.",
		},
	}
end