function data()
return {
	vehicles = {
		{ name = "vehicle/train/br53_preus_g3.mdl", forward = false },

	},
	name = _("Class 53 Prussian G 3 R"),
	desc = _("The Class G 3 was a family of six-coupled, medium-powered, freight train, tank locomotives.")
}
end