function data()
return {
	vehicles = {
		{ name = "vehicle/train/br89.mdl", forward = false },

	},
	name = _("Class 89 Prussian T 3 R"),
	desc = _("As a 0-6-0 tank locomotive, it was the first that was built to German state railway norms.")
}
end