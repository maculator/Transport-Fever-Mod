function data()
return {
	vehicles = {
		{ name = "vehicle/train/obb_1042.mdl", forward = false },

	},
	name = _("Class 1042 R"),
	desc = _("The Class 1042 was a class of electric locomotives operated by the Austrian Federal Railways.")
}
end