function data()
return {
	vehicles = {
		{ name = "vehicle/train/nohab.mdl", forward = false },

	},
	name = _("NoHAB AA16 R"),
	desc = _("This diesel-electric locomotive was a European variant of the American F-series from GM.")
}
end