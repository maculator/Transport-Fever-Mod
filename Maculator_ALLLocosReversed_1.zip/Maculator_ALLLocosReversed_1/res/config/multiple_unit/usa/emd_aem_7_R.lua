function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/emd_aem_7.mdl", forward = false },
	},
	name = _("EMD AEM-7 R"),
	desc = _("These locomotives used the latest in electric technology featuring thyristor motor control and traction motors that provided maximum power without wheel slip.")
}
end