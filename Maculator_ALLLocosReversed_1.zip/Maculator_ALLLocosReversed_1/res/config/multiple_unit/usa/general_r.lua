function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/general.mdl", forward = false },
	},
	name = _("4-4-0 The General R"),
	desc = _("This \"American\" type locomotive was very successful on many railroads in the US and is well known from the Buster Keaton film \"The General\".")
}
end