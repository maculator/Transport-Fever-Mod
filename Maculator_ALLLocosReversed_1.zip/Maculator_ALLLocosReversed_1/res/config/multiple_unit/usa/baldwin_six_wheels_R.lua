function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/baldwin_six_wheels.mdl", forward = false },
	},
	name = _("Baldwin's Six-Wheels R"),
	desc = _("The flexible-beam truck or six-wheels-connected engine was invented by Matthias Baldwin in 1842. His aim was to use all the locomotive's weight for traction.")
}
end