function data()
return {
	vehicles = {
		{ name = "vehicle/train/usa/bigboy.mdl", forward = false },
		{ name = "vehicle/train/usa/alco_pa.mdl", forward = false },
	},
	name = _("4-8-8-4 Big Boy R"),
	desc = _("This articulated locomotive was a real monster and carried the latest in steam technology. They were used primarily to haul freight over the Wasatch mountains between Green River and Ogden.")
}
end
